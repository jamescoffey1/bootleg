# ErBlan Private Store Clone

This is a React-based clone of the ErBlan private store landing page.

## How to Run

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the development server:
   ```bash
   npm start
   ```
3. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Features
- Modern dark theme
- Responsive layout
- Styled navigation bar, main content, and footer

---
This project is for educational and demonstration purposes only. 