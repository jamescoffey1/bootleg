import React, { useState, useRef } from "react";
import { BrowserRouter as Router, Routes, Route, Link, useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { AiOutlineHome } from "react-icons/ai";
import { AiOutlineHistory } from "react-icons/ai";
import { FaBitcoin } from "react-icons/fa";
import { FaUniversity } from "react-icons/fa";
import { MdOutlineSupportAgent } from "react-icons/md";
import { FiLogOut } from "react-icons/fi";
import { MdOutlineMail } from "react-icons/md";
import History from "./History";
import TopUp from "./TopUp";
import Banks from "./Banks";
import Login from "./Login";
import MatrixBackground from "./MatrixBackground";
import "./App.css";

function Home() {
  return (
    <main className="main-content">
      <h1>Welcome to ErBlan private store!</h1>
      <p className="subtitle">
        Our store boasts a self-written engine, an anti-DDoS system, and a bulletproof server. Don't journal!
      </p>
      <div className="attention">
        <b>Attention! New return format. After purchasing the item, you will have a return countdown, at the moment it is</b>
      </div>
      <ol className="rules">
        <li>Персональные данные клиентов хранятся в базе данных с нестандартным шифрованием и гарантированной безопасностью.</li>
        <li>Запрещена передача своих аккаунтов и ссылка на магазин 3-м лицам</li>
        <li>For all questions, please contact the chat directly in the store, or by Telegram: @erblansupport</li>
        <li>Replacing the invalid - return the cost account to an account in your personal account</li>
        <li>Accounts inactive for a month are - deleted for security reasons!</li>
        <li>За несоблюдение правил - удаление аккаунта без права восстановления.</li>
      </ol>
      <div className="return-policy">
        СОГЛАСНО ПРАВИЛАМ ВОЗВРАТА НАПИСАТЬ И УКАЗЫВАТЬ В ЖАБРАХ ПЕРЕД ПОКУПКОЙ!
      </div>
    </main>
  );
}

const pageVariants = {
  initial: { y: 40, opacity: 0 },
  animate: { y: 0, opacity: 1, transition: { duration: 0.4, ease: "easeOut" } },
  exit: { y: -40, opacity: 0, transition: { duration: 0.3, ease: "easeIn" } },
};

function AnimatedRoutes({ onLogout }) {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route
          path="/"
          element={
            <motion.div
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <Home />
            </motion.div>
          }
        />
        <Route
          path="/history"
          element={
            <motion.div
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <History />
            </motion.div>
          }
        />
        <Route
          path="/topup"
          element={
            <motion.div
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <TopUp />
            </motion.div>
          }
        />
        <Route
          path="/banks"
          element={
            <motion.div
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <Banks />
            </motion.div>
          }
        />
      </Routes>
    </AnimatePresence>
  );
}

const banksMenu = [
  {
    category: "USA",
    items: [
      "Wells Fargo", "Chase bank", "M&T bank", "Chime logs", "AFCU bank", "Navy Federal Bank",
      "Woodforest Bank", "BOA", "Citizens bank", "DCU bank", "TD bank", "53rd Bank + HELOC",
      "Huntington Bank", "TD BANK", "USAA bank", "Citi bank", "CIBC", "Truist Bank"
    ]
  },
  {
    category: "Other",
    items: ["Dumps", "Clone Cards", "Paypal"]
  }
];

function BanksDropdown({ open, setOpen }) {
  const navigate = useNavigate();
  return (
    <div
      className="banks-navbar-dropdown-wrapper"
      onMouseLeave={() => setOpen(false)}
      style={{ display: 'flex', alignItems: 'center', position: 'relative' }}
    >
      <Link to="/banks" style={{ display: "inline-block" }} onClick={() => setOpen(false)}>
        <button className="pixel-nav-btn" style={{paddingRight: 0, paddingLeft: 0, minWidth: 0, display: 'flex', alignItems: 'center'}}>
          <FaUniversity style={{ marginRight: 8, fontSize: 20, verticalAlign: "middle" }} />
          <span style={{fontWeight: 600, whiteSpace: 'nowrap'}}>Banks</span>
        </button>
      </Link>
      <button
        className={`banks-navbar-btn banks-navbar-arrow${open ? " active" : ""}`}
        style={{ marginLeft: 0, background: 'none', border: 'none', padding: 0, height: 56, display: 'flex', alignItems: 'center', cursor: 'pointer' }}
        onClick={e => { e.preventDefault(); setOpen(v => !v); }}
        tabIndex={0}
      >
        <span style={{ color: open ? "#e53935" : undefined, fontSize: '1.1em', display: 'inline-block', marginTop: 2, marginLeft: 2 }}>▼</span>
      </button>
      {open && (
        <div className="banks-navbar-dropdown">
          {banksMenu.map((cat) => (
            <div key={cat.category} className="banks-navbar-dropdown-category">
              <div className={`banks-navbar-dropdown-title${cat.category === "USA" ? " usa" : " other"}`}>{cat.category}</div>
              <div className="banks-navbar-dropdown-list">
                {cat.items.map((item) => (
                  <div key={item} className="banks-navbar-dropdown-item">{item}</div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function App() {
  const [banksOpen, setBanksOpen] = useState(false);
  const [loggedIn, setLoggedIn] = useState(true);
  const location = useLocation();
  React.useEffect(() => { setBanksOpen(false); }, [location]);

  return (
    <>
      <MatrixBackground />
      {loggedIn ? (
        <div className="app-bg">
          <nav className="navbar pixel-navbar">
            <div className="navbar-content pixel-navbar-content">
              <div className="navbar-links pixel-navbar-links">
                <Link to="/">
                  <button className="pixel-nav-btn"><AiOutlineHome style={{marginRight: 8, fontSize: 20, verticalAlign: "middle"}} /><span>Home</span></button>
                </Link>
                <Link to="/history">
                  <button className="pixel-nav-btn"><AiOutlineHistory style={{marginRight: 8, fontSize: 20, verticalAlign: "middle"}} /><span>History</span></button>
                </Link>
                <Link to="/topup">
                  <button className="pixel-nav-btn" style={{whiteSpace: 'nowrap'}}><FaBitcoin style={{marginRight: 8, fontSize: 20, verticalAlign: "middle"}} /><span>Top-up</span></button>
                </Link>
                <BanksDropdown open={banksOpen} setOpen={setBanksOpen} />
                <button className="pixel-nav-btn" onClick={() => window.open('https://web.telegram.org/a/#7854826672', '_blank', 'noopener,noreferrer')}><MdOutlineMail style={{marginRight: 8, fontSize: 20, verticalAlign: "middle"}} /><span>Customer Care</span></button>
                <button className="pixel-nav-btn" onClick={() => setLoggedIn(false)}><FiLogOut style={{marginRight: 8, fontSize: 20, verticalAlign: "middle"}} /><span>Logout</span></button>
              </div>
              <div className="navbar-balance pixel-navbar-balance">
                <button className="balance-btn pixel-balance-btn">
                  <span style={{display: 'flex', alignItems: 'center', justifyContent: 'center', whiteSpace: 'nowrap', minWidth: 0}}>
                    <FaBitcoin style={{marginRight: 8, fontSize: 18, verticalAlign: "middle"}} />
                    <span style={{fontWeight: 500, fontSize: '0.97rem', fontFamily: 'Inter, Arial, sans-serif', letterSpacing: '0.01em', whiteSpace: 'nowrap', minWidth: 0}}>Balance $0.00</span>
                  </span>
                </button>
              </div>
            </div>
          </nav>
          <AnimatedRoutes />
          <footer className="footer">
            Copyright © ErBlan | All rights reserved.
          </footer>
        </div>
      ) : (
        <Login onLogin={() => setLoggedIn(true)} />
      )}
    </>
  );
}

function AppWithRouter() {
  return (
    <Router>
      <App />
    </Router>
  );
}

export default AppWithRouter; 