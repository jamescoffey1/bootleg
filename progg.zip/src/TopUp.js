import React from "react";
import "./App.css";

export default function TopUp() {
  return (
    <div className="main-content topup-page">
      <h1 className="topup-welcome">Welcome, kkkkkkk</h1>
      <div className="topup-grid">
        <div className="topup-left">
          <div className="topup-card telegram-card">
            <div className="telegram-icon">📩</div>
            <div className="telegram-text">Send us a message on Telegram</div>
          </div>
          <div className="topup-card profile-card">
            <div className="profile-title">Profile Info.</div>
            <div>Username: kkkkkkk</div>
            <div>Email:</div>
            <div>Total Purchase:</div>
            <button className="change-password-btn">Change Password</button>
          </div>
        </div>
        <div className="topup-card topup-right">
          <h2 className="topup-title">Top-Up Balance</h2>
          <div className="topup-desc">
            This is your bitcoin deposit address, send only bitcoin to this address. Sending any other token will result in loss of assets.
          </div>
          <div className="btc-label">🪙 Bitcoin Deposit Address</div>
          <div className="btc-address">bc1qq70pxyqvn3u0tdr8vqscgqcgsjepuqxq94qfak</div>
          <div className="topup-warning">
            *Payments can take hours to confirm, do not panic when such happens, if after 24 hours of payment there is no reflection, contact support.
          </div>
          <button className="copy-address-btn">Copy Address</button>
        </div>
      </div>
    </div>
  );
} 