import React from "react";
import "./App.css";

export default function History() {
  return (
    <div className="main-content history-page">
      <div className="history-header-row">
        <h1 className="history-title">Purchase History</h1>
        <div className="history-info">
          EMAIL ACCESS LOGIN(USER & PW) - SSN + DOB - WIRE & ZELLE ENABLED<br />
          - COOKIES - IP/UA - AN/RN - PHONE# - RDP ACCESS CARRIER PIN - DL - CVV/EXP - BILLPAY OFF
          <br /><br />
          <b>User:</b> kkkkkkk<br />
          <b>Email:</b> gesafo5283@forcrack.com<br />
          <b>Total Purchase:</b> 0
        </div>
      </div>
      <div className="history-no-data">No History available.</div>
    </div>
  );
} 