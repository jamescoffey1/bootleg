import React, { useState } from "react";
import { FaUserAlt, FaEnvelope, FaLock } from "react-icons/fa";
import "./App.css";
import MatrixBackground from "./MatrixBackground";

export default function Login({ onLogin }) {
  const [mode, setMode] = useState(null); // null, 'login', 'signup'
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [signupUsername, setSignupUsername] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  function handleSignup(e) {
    e.preventDefault();
    if (!signupUsername || !signupEmail || !signupPassword) {
      setError("Please fill in all fields.");
      return;
    }
    localStorage.setItem(
      "erblan_user",
      JSON.stringify({ username: signupUsername, email: signupEmail, password: signupPassword })
    );
    setSuccess("Account created! You can now log in.");
    setError("");
    setMode("login");
    setUsername(signupUsername);
    setEmail(signupEmail);
    setPassword("");
  }

  function handleLogin(e) {
    e.preventDefault();
    const stored = localStorage.getItem("erblan_user");
    if (!stored) {
      setError("No account found. Please sign up first.");
      return;
    }
    const { username: storedUser, email: storedEmail, password: storedPass } = JSON.parse(stored);
    if (
      username === storedUser &&
      email === storedEmail &&
      password === storedPass
    ) {
      setError("");
      setSuccess("");
      if (onLogin) onLogin();
    } else {
      setError("Invalid credentials.");
    }
  }

  return (
    <>
      <MatrixBackground />
      <div className="login-bg">
        <div className="login-center">
          {mode === null && (
            <>
              <button className="login-btn" onClick={() => setMode("login")}>Login</button>
              <button className="login-btn" onClick={() => setMode("signup")}>Sign-up</button>
            </>
          )}
          {mode === "signup" && (
            <form className="signup-card" onSubmit={handleSignup}>
              <div className="signup-title">Welcome back</div>
              <label className="signup-label"><FaUserAlt className="signup-icon" /> Username</label>
              <input
                className="signup-input"
                placeholder="Enter your user name"
                value={signupUsername}
                onChange={e => setSignupUsername(e.target.value)}
                autoFocus
              />
              <label className="signup-label"><FaEnvelope className="signup-icon" /> Email</label>
              <input
                className="signup-input"
                placeholder="Enter your email address"
                value={signupEmail}
                onChange={e => setSignupEmail(e.target.value)}
                type="email"
              />
              <label className="signup-label"><FaLock className="signup-icon" /> Password</label>
              <input
                className="signup-input"
                placeholder="Enter your password"
                type="password"
                value={signupPassword}
                onChange={e => setSignupPassword(e.target.value)}
              />
              <div className="signup-remember-row">
                <input type="checkbox" id="signup-remember" checked={remember} onChange={e => setRemember(e.target.checked)} />
                <label htmlFor="signup-remember" className="signup-remember-label">Remember me</label>
              </div>
              <button className="signup-btn" type="submit">Sign Up</button>
              {error && <div className="login-form-error">{error}</div>}
              {success && <div className="login-form-success">{success}</div>}
              <div className="signup-divider-row">
                <div className="signup-divider" />
                <span className="signup-or">OR</span>
                <div className="signup-divider" />
              </div>
              <div className="signup-bottom-link">
                Already have an account?{' '}
                <span className="signup-link" onClick={() => setMode("login")}>Login here</span>
              </div>
            </form>
          )}
          {mode === "login" && (
            <form className="signup-card" onSubmit={handleLogin}>
              <div className="signup-title">Welcome back</div>
              <label className="signup-label"><FaUserAlt className="signup-icon" /> Username</label>
              <input
                className="signup-input"
                placeholder="Enter your user name"
                value={username}
                onChange={e => setUsername(e.target.value)}
                autoFocus
              />
              <label className="signup-label"><FaEnvelope className="signup-icon" /> Email</label>
              <input
                className="signup-input"
                placeholder="Enter your email address"
                value={email}
                onChange={e => setEmail(e.target.value)}
                type="email"
              />
              <label className="signup-label"><FaLock className="signup-icon" /> Password</label>
              <input
                className="signup-input"
                placeholder="Enter your password"
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
              <div className="signup-remember-row">
                <input type="checkbox" id="login-remember" checked={remember} onChange={e => setRemember(e.target.checked)} />
                <label htmlFor="login-remember" className="signup-remember-label">Remember me</label>
              </div>
              <button className="signup-btn" type="submit">Login</button>
              {error && <div className="login-form-error">{error}</div>}
              {success && <div className="login-form-success">{success}</div>}
              <div className="signup-divider-row">
                <div className="signup-divider" />
                <span className="signup-or">OR</span>
                <div className="signup-divider" />
              </div>
              <div className="signup-bottom-link">
                Don't have an account?{' '}
                <span className="signup-link" onClick={() => setMode("signup")}>Sign up here</span>
              </div>
            </form>
          )}
        </div>
        <div className="login-watermark">ErBlan</div>
        <div className="login-copyright">ErBlan © 2015-2024</div>
      </div>
    </>
  );
} 